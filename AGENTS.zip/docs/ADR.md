# Architecture Decision Records

## Philosophy
`mestemplate` is a learning-first MES backend platform template.

The project should grow as a reusable platform foundation, not as a customer-specific SI codebase. Customer-specific requirements should be handled through configuration, extension points, or separate adapters whenever possible. Source-code forks are a last resort.

---

### ADR-001: Use Spring Boot 3.4.3

**Decision**: Use Spring Boot `3.4.3` with Java 17.

**Reason**:
- It matches the existing SI reference project's stable baseline.
- It keeps the learning path aligned with widely used Spring Boot 3.x conventions.
- It avoids adding Spring Boot 4.x migration concerns before the platform foundation is understood.

**Tradeoff**:
- We do not use the newest Spring Boot 4.x line yet.
- Future upgrades should be handled deliberately after the first vertical slice is stable.

---

### ADR-002: Start As A Modular Monolith

**Decision**: Build one Spring Boot application with package-level module boundaries first.

**Reason**:
- MES domains are tightly connected: item, inventory, work order, quality, equipment, and lot tracking often interact.
- Microservices require clear ownership, deployment maturity, data boundaries, observability, and tenant isolation policies.
- The first goal is a working vertical slice, not distributed-system complexity.

**Tradeoff**:
- Module boundaries are enforced by discipline and package structure at first.
- Separate Gradle modules or services may be introduced later only when boundaries become stable.

---

### ADR-003: Use Shared Database With Tenant ID First

**Decision**: Use a shared database with `tenant_id` on business tables as the default multi-tenant model.

**Reason**:
- It is the simplest practical model for an early reusable platform.
- One application and one database are easier to run, test, and understand.
- Tenant isolation is still explicit because every business row carries `tenant_id`.
- It fits a template product that should be adaptable to many customers without creating a separate codebase per customer.

**Tradeoff**:
- Every API, query, repository method, and unique constraint must include tenant scope.
- A missed `tenant_id` condition can leak data across tenants.
- Strong operational isolation is weaker than schema-per-tenant or database-per-tenant.

**Alternative Considered: Database Per Customer**:
- This is practical for large enterprise customers that require strong isolation, independent backup/restore, separate maintenance windows, or contractual data separation.
- It increases operational complexity because migrations, monitoring, backups, and deployments must be managed per customer database.
- It is not the recommended default for this learning template.

**Future Option**:
- Keep the domain and application layers independent from the physical tenant strategy so that database-per-customer can be supported later by configuration and infrastructure, not by rewriting business code.

---

### ADR-004: Treat Customer Differences As Extension Points

**Decision**: The platform core should not contain customer-specific branches such as `if (companyCode.equals("A"))`.

**Reason**:
- A platform should have a stable core that can serve multiple manufacturers.
- Customer differences should first be modeled as data, configuration, workflow definitions, permissions, feature flags, or adapters.
- Only repeated customer patterns should be promoted into platform capabilities.

**Tradeoff**:
- Some early requirements may take more design thought than direct SI-style coding.
- We should still avoid premature abstractions; an extension point is added only when a real variation appears.

---

### ADR-005: Start With Manual Mappers

**Decision**: Use manual mapping code for the first vertical slice.

**Reason**:
- Manual mappers make data flow between web DTOs, application DTOs, domain objects, and JPA entities easy to understand.
- They avoid generated-code complexity while the architecture is still being learned.
- The first item master slice has a small enough field set for manual mapping.

**Tradeoff**:
- Mapping code can become repetitive as modules grow.
- MapStruct can be introduced later when DTO/entity mapping repetition becomes a real maintenance cost.

---

### ADR-006: Exclude Flyway For The First Learning Slice

**Decision**: Do not introduce Flyway in the first implementation phase.

**Reason**:
- The first goal is to understand the vertical architecture and tenant-aware data flow.
- Database migration tooling can distract from the first learning slice.

**Tradeoff**:
- This is not production-ready database change management.
- Flyway or Liquibase must be reconsidered before staging, production, or team-based schema evolution.

---

### ADR-007: Build Item Master As The First Vertical Slice

**Decision**: Implement item master first.

**Reason**:
- Item master is a core MES concept.
- It has fewer dependencies than purchase, inventory, work order, or receiving flows.
- It is suitable for learning the complete request-to-database-to-response path.

**Tradeoff**:
- It does not immediately demonstrate complex MES workflows.
- Workflow-heavy modules should wait until the platform's base conventions are clear.

---

### ADR-008: Use QueryDSL For List And Search Queries

**Decision**: Use QueryDSL for list/search APIs and dynamic read queries.

**Reason**:
- MES systems rely heavily on searchable operational lists.
- Future modules such as inventory, receiving, work order, quality, and equipment will require joins, optional filters, and DTO projections.
- Establishing the QueryDSL convention in the item slice prepares the project for realistic MES read models.

**Tradeoff**:
- QueryDSL adds annotation processing and generated Q classes.
- The first slice becomes slightly harder than using only Spring Data JPA.
- Simple writes and simple lookups should still use Spring Data JPA where it is clearer.

---

### ADR-009: Validate The Platform Through Mini MES V1

**Decision**: After item master, grow the project toward an inventory-centered Mini MES v1.

**Mini MES V1 Scope**:
```text
item master
warehouse master
location master
receiving
material issue
inventory balance
stock movement history
```

**Reason**:
- This creates a small but realistic manufacturing flow.
- Inventory movement is easier to validate than full production execution, but still useful enough to feel like a real MES backend.
- It gives the developer a concrete target instead of an abstract "build all MES modules" goal.

**Tradeoff**:
- Production, quality, equipment, and lot tracking are delayed.
- Some platform concerns such as JWT and authorization may start simple and mature after the first inventory flow works.

---

### ADR-010: Add User Master Before Full Authentication

**Decision**: Add a small tenant-scoped user master slice before implementing full login, JWT, OAuth2/OIDC, or fine-grained permission management.

**Scope**:
```text
create user
update user
get user by id
search user list
soft delete user
```

Initial user fields:
```text
id
tenant_id
login_id
password_hash
display_name
role
status
deleted
created_at
updated_at
```

Initial role model:
```text
TENANT_ADMIN
MES_MANAGER
MES_OPERATOR
VIEWER
```

Initial status model:
```text
ACTIVE
LOCKED
DISABLED
```

**Reason**:
- MES minimum-permission work needs a user identity anchor before meaningful authorization can be added.
- A small user master slice lets the project reuse the established item architecture: web DTOs, application DTOs, use case, service, domain object, repository port, persistence adapter, mapper, entity, repository, and QueryDSL search.
- Password hashing can be introduced early without committing to the final authentication flow.
- Tenant-scoped user storage makes the later current-user/current-tenant context easier to add.

**Current Security Boundary**:
- The user API is an early admin/bootstrap API, not a complete public identity API.
- Tenant still comes from `X-Tenant-Id`, which is caller-controlled.
- Role and status are accepted from request DTOs.
- There is no login API, JWT, current-user/current-tenant context, or permission gate yet.

**Persistence Rule**:
- `login_id` is unique inside a tenant.
- The first implementation reserves login IDs even after soft delete by using a tenant/login unique constraint.
- If login reuse after soft delete becomes necessary, it should be decided explicitly and implemented with a migration-aware database constraint strategy.

**Tradeoff**:
- This moves part of Phase 3 identity work earlier than the original roadmap.
- It gives the platform a practical minimum-permission foundation, but endpoints must not be treated as production-secure until authentication and authorization are implemented.

**Next Step**:
- Add a current-user/current-tenant context.
- Replace trusted `X-Tenant-Id` usage with authenticated tenant resolution.
- Add authorization checks for user administration.
- Add tenant-isolation integration tests for user APIs and repositories.
