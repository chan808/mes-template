# Architecture

## Architecture Goal
`mestemplate` starts as a modular monolith for a reusable MES backend platform.

The system should provide a clean common foundation that can be adapted to different manufacturers with minimal source-code changes. Customer-specific behavior should be handled through configuration, data-driven rules, feature flags, workflow definitions, strategy interfaces, or customer-specific adapters.

The platform core must avoid customer-specific branches in business logic.

## Recommended Package Structure

Use package-level modules before splitting Gradle modules or services.

```text
src/main/java/com/sainti/mestemplate
├── MestemplateApplication.java
├── global
│   ├── response
│   ├── error
│   ├── tenant
│   └── persistence
└── item
    ├── adapter
    │   ├── in
    │   │   └── web
    │   │       └── dto
    │   └── out
    │       └── persistence
    │           ├── entity
    │           ├── mapper
    │           └── repository
    ├── application
    │   ├── dto
    │   └── port
    │       ├── in
    │       └── out
    └── domain
```

Package responsibilities:

```text
adapter/in/web
- HTTP controllers
- Request binding
- Bean Validation
- Response wrapping

adapter/in/web/dto
- External API DTOs
- Request, Search, Response classes

application
- Use cases
- Application services
- Transaction boundaries

application/port/in
- Inbound application ports
- Interfaces used by inbound adapters such as controllers
- Example: ItemUseCase

application/port/out
- Outbound application ports
- Interfaces required by application services
- Example: ItemRepositoryPort

application/dto
- Command, Query, Result classes

domain
- Business state and invariants
- Domain creation and state-change methods

adapter/out/persistence
- Repository port implementations
- JPA/QueryDSL access
- Domain/entity conversion

adapter/out/persistence/entity
- JPA table mappings only

adapter/out/persistence/repository
- Spring Data JPA repositories
- QueryDSL repositories for search/list queries
```

## Request Flow

```text
Client
-> Controller
-> web dto: Request/Search
-> application dto: Command/Query
-> UseCase
-> Service
-> Domain
-> RepositoryPort
-> RepositoryAdapter
-> Mapper
-> Entity / Repository / QueryDSL
-> Database
```

## Response Flow

```text
Database
-> JPA / QueryDSL
-> application dto: Result
-> web dto: Response
-> ApiResponse
-> Client
```

## Multi-Tenant Model

The default tenant model is:

```text
shared database + tenant_id on business tables
```

Tenant means the customer or organization that owns the data. It is not the same as factory.

```text
tenant_id
- Top-level data owner
- Example: Customer A, Customer B

factory_id / site_id
- A plant or site inside one tenant
- Used for operational filtering inside the tenant boundary
```

Every business table should eventually include `tenant_id`.

Example:

```text
item
- id
- tenant_id
- item_code
- item_name
- item_type
- unit
- status
- deleted
- created_at
- updated_at
```

Every read/write operation must be tenant-scoped.

```text
Correct:
where tenant_id = currentTenantId
  and id = requestedId
  and deleted = false

Incorrect:
where id = requestedId
  and deleted = false
```

Unique constraints should also include tenant scope.

```text
unique(tenant_id, item_code)
```

For the first learning version, tenant can be passed by an explicit request header:

```text
X-Tenant-Id: 1
```

Later, tenant should come from authenticated user context or JWT claims instead of trusting request body fields.

## Database Per Customer

Database-per-customer is a valid real-world option when a customer requires strong operational isolation.

It is useful when:

```text
- customer contracts require separate databases
- backup and restore must be customer-specific
- maintenance windows differ by customer
- data residency or compliance rules require hard separation
- one large customer has a much heavier workload than others
```

It is not the default for this project because it increases:

```text
- migration complexity
- deployment coordination
- monitoring and backup work
- local development setup cost
- test environment cost
```

The platform should keep this future option open by avoiding tenant strategy assumptions in domain logic.

## Customer Customization Model

The intended product model is:

```text
platform core
-> reusable default MES features
-> customer configuration
-> optional customer adapters or extension implementations
```

The goal is not to copy the template and heavily edit it per customer. That quickly becomes multiple SI forks.

Preferred customization order:

```text
1. configuration
2. role/permission settings
3. common code or master data
4. feature flags
5. workflow definitions
6. strategy interface implementation
7. customer-specific adapter
8. source-code fork only as a last resort
```

Examples:

```text
Good:
- item code format configured per tenant
- approval workflow defined in data
- customer-specific ERP integration implemented as an adapter

Bad:
- if tenantCode == "CUSTOMER_A" inside core service
- duplicated module per customer
- exposing JPA entity fields directly because one customer needs them
```

## Mapper Policy

Start with manual mappers.

Objects should stay separated by layer:

```text
ItemCreateRequest
-> CreateItemCommand
-> Item
-> ItemEntity
-> ItemResult
-> ItemResponse
```

Manual mapping is preferred in the first slice because it makes the flow easy to read and debug.

MapStruct can be introduced later when mapping repetition becomes a clear maintenance issue.

## Query Policy

Use this split for persistence:

```text
Spring Data JPA
- simple save
- simple exists
- simple find by id

QueryDSL
- list/search APIs
- dynamic filtering
- joins
- DTO projection
- aggregate read models
```

Reason:

```text
MES screens commonly require complex list queries:
- item + category + status
- inventory + warehouse + location + lot
- receiving + vendor + purchase order + inspection status
- work order + line + equipment + item + progress status
```

The first item search should use QueryDSL so the project establishes the long-term read-query convention early.

## First Vertical Slice

The first slice is item master.

Scope:

```text
Create item
Update item
Get item by id
Search item list
Soft delete item
```

Initial fields:

```text
id
tenantId
itemCode
itemName
itemType
unit
status
description
deleted
createdAt
updatedAt
```

The first slice must demonstrate:

```text
- explicit API versioning: /api/v1/items
- request DTO validation
- command/query/result separation
- domain object creation and update methods
- repository port usage
- JPA entity separation
- tenant-scoped persistence queries
- QueryDSL-based list/search query
- soft delete
- consistent ApiResponse
- at least one test around domain behavior
```

## Identity Slice

After the item master slice, the project adds a small user master slice as the first identity and minimum-permission foundation.

The current user slice follows the same modular flow as item:

```text
UserController
-> UserCreateRequest / UserUpdateRequest / UserSearch
-> CreateUserCommand / UpdateUserCommand / UserQuery
-> UserUseCase
-> UserService
-> User
-> UserRepositoryPort
-> UserRepositoryAdapter
-> UserPersistenceMapper
-> UserEntity / UserJpaRepository / UserQueryRepository
-> DB
```

Initial user fields:

```text
id
tenantId
loginId
passwordHash
displayName
role
status
deleted
createdAt
updatedAt
```

Initial user role values:

```text
TENANT_ADMIN
MES_MANAGER
MES_OPERATOR
VIEWER
```

Initial user status values:

```text
ACTIVE
LOCKED
DISABLED
```

The user slice demonstrates:

```text
- explicit API versioning: /api/v1/users
- request DTO validation
- command/query/result separation
- domain object creation, update, and soft delete methods
- repository port usage
- JPA entity separation
- tenant-scoped persistence queries
- QueryDSL-based list/search query
- password hashing through PasswordEncoder before persistence
- no passwordHash exposure in API responses
- tenant-scoped unique login id at the entity/table mapping level
```

For the learning version, user APIs still receive tenant through `X-Tenant-Id`, matching item. This remains temporary. The current user endpoints should be treated as admin/bootstrap endpoints until authentication and authorization are implemented.

Important current limitations:

```text
- X-Tenant-Id is caller-controlled
- user creation can assign roles from request data
- user update can change role and status from request data
- there is no current-user/current-tenant context yet
- there is no permission gate around user administration yet
```

The next security step should centralize tenant resolution through a current-user/current-tenant context and later derive it from authenticated user data or JWT claims. After that, user administration should require an explicit permission such as tenant administration or user management.

The user slice intentionally does not include:

```text
- login API
- JWT access/refresh tokens
- OAuth2/OIDC
- password reset
- role/permission management screens
- fine-grained permission tables
- object-level authorization beyond tenant-scoped repository access
```

## Mini MES V1 Target Flow

After item master, the platform should grow toward a small but usable inventory-centered MES flow:

```text
Register item
-> Register warehouse/location
-> Receive material
-> Increase inventory balance
-> Issue material
-> Decrease inventory balance
-> Query stock movement history
```

This flow is the first practical validation that the template is more than CRUD scaffolding.

## Reference Project Usage

`woojinplastic-material` is a reference sample, not source to copy directly.

Useful parts:

```text
- vertical package flow
- use case and repository port idea
- QueryDSL search repository pattern
- header/detail transaction examples
```

Parts to avoid copying:

```text
- customer package names
- customer-specific schema assumptions
- external private core dependencies
- string status fields where enums are stable
- missing request validation
- factory_id used as the top-level boundary
- hard-coded secrets or environment values
```
