# AI Orchestration Guide

This guide explains how to use Codex sub-agents for `mestemplate`.

Use `AGENTS.md` as the project-level rulebook. Use this file as the day-to-day operating guide for splitting work between the main agent and sub-agents.

## Default Recommendation

Do not start with a TOML agent configuration.

For this project, Markdown is the better first format because the important work is judgment-heavy:

- deciding the smallest useful next step
- keeping the learning path visible
- protecting the modular monolith architecture
- reviewing code before broadening the slice
- explaining choices in plain language

Use TOML only later if there is a real tool that reads it, such as a recurring automation, a custom runner, or a repeatable CI-like workflow. Until then, keep orchestration rules readable and easy to edit.

## Main Agent Role

The main agent owns the whole task.

Responsibilities:

- clarify the user goal
- inspect the current code before planning
- choose the next small vertical step
- delegate only bounded side tasks
- integrate sub-agent findings
- review code for architectural drift
- run compile or tests when practical
- explain the result in plain language

The main agent should not outsource the final decision.

## Sub-Agent Roles

Reusable role profiles live in:

- `docs/agents/architecture-explorer.md`
- `docs/agents/development-worker.md`
- `docs/agents/senior-pr-reviewer.md`

When delegating, paste or reference the relevant profile and add the exact current task below it. Keep the current task more specific than the persona.

### Explorer

Use an explorer for read-only codebase investigation.

Good tasks:

- find existing project conventions
- map package structure
- identify current test coverage
- compare implementation against `AGENTS.md`
- inspect one layer, such as controller, service, or persistence

Avoid:

- broad requests like "understand the whole platform"
- implementation work
- duplicate exploration already done by another agent

Example prompt:

```text
Use the role profile in docs/agents/architecture-explorer.md.

Inspect the current item master implementation. Focus only on package structure, request flow, response flow, and whether it follows AGENTS.md. Do not edit files. Return concise findings with file paths.
```

### Worker

Use a worker for a small, clearly owned code change.

Good tasks:

- add one domain behavior and its test
- implement one DTO mapper
- fix one failing test class
- add validation to one request DTO group
- implement one adapter method

Worker prompts must include:

- exact ownership scope
- files or package area they may edit
- expected tests to run
- instruction not to revert unrelated changes

Example prompt:

```text
Use the role profile in docs/agents/development-worker.md.

You are not alone in the codebase. Do not revert changes made by others.

Implement only the item web request validation updates under:
- src/main/java/com/sainti/mestemplate/item/adapter/in/web/dto
- src/test/java/com/sainti/mestemplate/item/adapter/in/web

Follow the existing DTO and controller test style. Run the relevant tests if possible. In your final answer, list changed files and any tests run.
```

### Reviewer

Use a reviewer after a small implementation when the risk is design drift, missing validation, or test gaps.

Good tasks:

- review one vertical slice
- check object-level authorization assumptions
- check tenant isolation gaps
- check API response consistency
- check persistence boundary violations

Example prompt:

```text
Use the role profile in docs/agents/senior-pr-reviewer.md.

Review the item master slice against AGENTS.md. Focus on bugs, missing validation, security risks, tenant isolation gaps, and architectural drift. Do not edit files. Return findings ordered by severity with file paths.
```

## First Useful Orchestration Pattern

Use this pattern when starting a new slice or reviewing the current item slice.

1. Main agent inspects repository status and recent files.
2. Explorer A checks architecture and package flow.
3. Explorer B checks tests and missing coverage.
4. Main agent combines findings into the smallest next implementation step.
5. One worker implements only that step.
6. Main agent reviews the diff and runs tests.

This keeps the work small enough to understand.

## Suggested First Prompt

Use this when you want to practice orchestration without changing code:

```text
Use sub-agents to analyze the current project.

Explorer 1: inspect the Gradle/Spring Boot structure and summarize the current implemented layers.
Explorer 2: inspect the item master slice against AGENTS.md and identify the smallest missing pieces.

The main agent should not edit files. Combine the results into the next three practical steps.
```

Use this when you are ready for a small implementation:

```text
Use sub-agents for a small implementation step.

First, use an explorer to confirm the current conventions for the target layer.
Then use one worker to implement only the smallest agreed change.
The main agent should review the diff, run relevant tests, and explain the result.
```

## Delegation Rules For This Project

- Prefer one worker at a time until the first item slice is stable.
- Use multiple explorers only when their questions are clearly different.
- Do not let two workers edit the same package at the same time.
- Do not create broad framework abstractions before a vertical slice proves the need.
- Do not add many empty modules for future MES concepts.
- Keep every implementation task explainable by a Java/Spring learner.
- Run `.\gradlew.bat test` or a narrower relevant test command after code changes when practical.

## Good Task Sizes

Good:

- "Add validation to item create and update requests."
- "Review only ItemService for domain/application boundary issues."
- "Add a repository integration test for create and find by id."
- "Explain why ItemRepositoryPort exists in this slice."

Too large:

- "Build the MES platform."
- "Add security, tenant isolation, and all modules."
- "Refactor the whole architecture."
- "Generate material, inventory, work order, and quality modules."

## When TOML May Become Useful

Create a TOML file later only if one of these becomes true:

- Codex automations need a saved recurring task.
- A custom local script reads agent task definitions.
- The project introduces repeatable review profiles.
- CI or a developer tool consumes the configuration.

Possible future file:

```text
docs/agent-profiles.toml
```

Do not add it until there is a consumer for the file.
