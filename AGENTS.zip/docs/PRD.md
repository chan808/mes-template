# PRD: mestemplate

## Product Goal
`mestemplate` is a backend template for building a reusable MES platform.

The goal is to create a clean platform foundation that can be adapted to different manufacturers with minimal source-code changes.

This is not a customer-specific SI project. It should help us learn and define a stable MES backend architecture before adding many business modules.

The practical first product target is:

```text
Mini MES v1
```

Mini MES v1 should be small enough for a junior developer to understand end to end, but real enough to demonstrate a usable manufacturing flow:

```text
item master
-> warehouse/location master
-> receiving
-> stock increase
-> material issue
-> stock decrease
-> stock movement history
```

## Target Users

Primary users:

```text
- backend developers learning MES platform architecture
- internal developers building reusable MES modules
- implementation teams adapting the platform to manufacturers
```

Future business users:

```text
- manufacturing managers
- production planners
- inventory managers
- quality managers
- equipment maintenance managers
- shop-floor operators
```

## Platform Positioning

The intended product shape is:

```text
reusable MES backend platform
plus customer-specific configuration
plus optional adapters or extension implementations
```

The desired implementation model is not:

```text
copy project per customer
then heavily modify source code
then maintain many divergent forks
```

Customer-specific differences should be handled through platform mechanisms whenever possible:

```text
- tenant settings
- master data
- common codes
- role and permission configuration
- feature flags
- workflow definitions
- strategy interfaces
- external integration adapters
```

Source-code changes per customer should be small, explicit, and isolated.

## MVP Scope

The first MVP step is one working vertical slice:

```text
item master
```

Required item master operations:

```text
1. Create item
2. Update item
3. Get item by id
4. Search item list
5. Soft delete item
```

The first slice should prove these platform conventions:

```text
- Spring Boot 3.4.3 backend baseline
- REST API versioning with /api/v1
- consistent API response wrapper
- consistent exception response
- request DTO validation
- application command/query/result DTOs
- domain object separated from JPA entity
- repository port separated from Spring Data JPA repository
- tenant_id included in business data
- tenant-scoped read/write queries
- soft delete
- manual mapper convention
- QueryDSL-based list/search convention
```

After the item slice is stable, the MVP should grow into Mini MES v1:

```text
1. item master
2. warehouse master
3. location master
4. receiving
5. material issue
6. inventory balance
7. stock movement history
```

The project also now includes a small user master slice as an early identity foundation:

```text
user master
```

Required user master operations:

```text
1. Create user
2. Update user
3. Get user by id
4. Search user list
5. Soft delete user
```

The user master slice proves these additional platform conventions:

```text
- tenant-scoped user data
- tenant-scoped login id uniqueness
- database-level unique constraint for tenant_id + login_id
- coarse role enum for first minimum-permission modeling
- user status enum for account lifecycle
- password hashing before persistence
- password hash excluded from API responses
- same web/application/domain/persistence layering as item
```

The current user API should be treated as an early admin/bootstrap API, not a complete public identity API. Until login, JWT, current-user context, and authorization checks exist, user creation and role changes still trust the temporary `X-Tenant-Id` header.

## Initial Item Fields

Start small.

```text
id
tenantId
itemCode
itemName
itemType
unit
status
description
deleted
createdAt
updatedAt
```

Possible initial enums:

```text
itemType: PRODUCT, MATERIAL, SEMI_FINISHED, CONSUMABLE
status: ACTIVE, INACTIVE
```

Do not add BOM, inventory quantity, routing, process, quality rules, or customer-specific attributes in the first item slice.

## Initial User Fields

Start small.

```text
id
tenantId
loginId
passwordHash
displayName
role
status
deleted
createdAt
updatedAt
```

Possible initial enums:

```text
role: TENANT_ADMIN, MES_MANAGER, MES_OPERATOR, VIEWER
status: ACTIVE, LOCKED, DISABLED
```

Do not add JWT, refresh tokens, password reset, OAuth2/OIDC, fine-grained permission tables, or menu authorization in the first user slice.

Current user-slice limitations to resolve before real service launch:

```text
- tenant still comes from X-Tenant-Id, not authenticated user context
- user administration has no permission gate yet
- role changes are accepted from the request body
- password policy is minimal
- repository/API integration tests for tenant isolation are not complete yet
```

## Multi-Tenant Requirement

The first version uses:

```text
shared database + tenant_id
```

Business data should be designed as tenant-owned from the start.

In the learning phase, tenant may be supplied through:

```text
X-Tenant-Id
```

Later, tenant must come from authenticated user context or JWT claims.

The platform must avoid treating `factory_id` as a tenant replacement. Factory is a lower-level operational scope inside a tenant.

## MVP Exclusions

The first item slice does not include:

```text
- full JWT authentication
- OAuth2/OIDC
- role/permission management beyond the initial user role enum
- approval workflow engine
- purchase request/order/receiving workflows
- work order execution
- quality inspection workflows
- equipment downtime tracking
- lot tracking
- file attachment
- audit log UI
- customer-specific ERP/MES integration
- Flyway/Liquibase migrations
- database-per-customer runtime routing
- microservices
```

These are future platform capabilities, not first-slice requirements.

For Mini MES v1, receiving, material issue, inventory balance, and stock movement history are included. Purchase request/order, production, quality, and equipment remain later phases.

## Product Roadmap

Recommended development phases:

```text
Phase 0: Platform foundation
- Spring Boot 3.4.3
- common response and error handling
- tenant_id policy
- item master vertical slice
- user master vertical slice
- password hashing baseline

Phase 1: Mini MES master data
- warehouse
- location
- basic factory/site model if needed

Phase 2: Mini MES inventory flow
- receiving
- material issue
- inventory balance
- stock movement history

Phase 3: Identity and authorization
- login API
- JWT
- current-user/current-tenant context
- role and permission expansion
- tenant from authenticated user context

Phase 4: Production basics
- work order
- production result
- lot creation and tracking

Phase 5: Quality and equipment
- inspection
- defect records
- equipment downtime
```

## Success Criteria

The first item slice is successful when:

```text
- item API can create, update, get, search, and soft-delete items
- item data is always scoped by tenant_id
- request validation catches invalid item input
- domain logic is testable without Spring
- services depend on repository ports, not JPA repositories
- controllers do not expose JPA entities
- the project builds with Spring Boot 3.4.3
- the code is understandable enough to explain layer by layer
```

Mini MES v1 is successful when:

```text
- a tenant can register items, warehouses, and locations
- a tenant can receive material and increase stock
- a tenant can issue material and decrease stock
- current inventory balance can be queried by item and location
- stock movement history shows why stock changed
- tenant A cannot read or modify tenant B data
```

## Reference SI Project Usage

`woojinplastic-material` is used only as a reference for:

```text
- typical MES material workflows
- package layering ideas
- use case and repository port naming
- QueryDSL list/search examples
```

It should not be copied as platform core because it contains customer-specific assumptions and private dependencies.
